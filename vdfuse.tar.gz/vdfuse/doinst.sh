echo "user_allow_other" >> /etc/fuse.conf
chmod 644 /etc/fuse.conf
